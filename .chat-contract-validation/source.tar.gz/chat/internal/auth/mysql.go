package auth

import (
	"context"
	"crypto/subtle"
	"database/sql"
	"encoding/json"
	"time"

	"github.com/franz-9527/workers/chat/internal/ports"
)

// MySQLSource is SELECT-only on PHP-owned identity tables. No last_seen writes.
type MySQLSource struct{ db *sql.DB }

func NewMySQLSource(db *sql.DB) (*MySQLSource, error) {
	if db == nil {
		return nil, ports.ErrInvalid
	}
	return &MySQLSource{db}, nil
}
func (s *MySQLSource) Validate(ctx context.Context, c Claims) error {
	if c.Kind != "mini" {
		if c.Kind == "admin" {
			return s.validateAdmin(ctx, c)
		}
		return ErrUnauthorized
	}
	var actor, hash string
	var expires int64
	err := s.db.QueryRowContext(ctx, `SELECT CAST(s.user_id AS CHAR),s.token_hash,UNIX_TIMESTAMP(s.expires_at)
 FROM login_sessions s JOIN users u ON u.id=s.user_id AND u.status='active'
 WHERE s.id=? AND s.status='active' AND s.expires_at>UTC_TIMESTAMP()
 AND COALESCE(s.demo_actor_user_id,0)=0 AND COALESCE(s.test_actor_user_id,0)=0
 AND COALESCE(s.test_instance_id,0)=0 AND s.test_actor_expires_at IS NULL LIMIT 1`, string(c.SourceID)).Scan(&actor, &hash, &expires)
	if err == sql.ErrNoRows {
		return ErrUnauthorized
	}
	if err != nil {
		return ports.ErrUnavailable
	}
	sid := digest("mini\n" + string(c.SourceID) + "\n" + hash)
	version := digest("mini-v1\n" + string(c.SourceID) + "\n" + hash + "\n" + actor)
	if actor != string(c.ActorID) || !hex64.MatchString(hash) || subtle.ConstantTimeCompare([]byte(sid), []byte(c.SessionID)) != 1 || subtle.ConstantTimeCompare([]byte(version), []byte(c.Version)) != 1 || expires <= time.Now().Unix() || c.ExpiresAt > expires {
		return ErrUnauthorized
	}
	return nil
}

func (s *MySQLSource) validateAdmin(ctx context.Context, c Claims) error {
	var actor, sid, version, scopesJSON string
	var expires int64
	err := s.db.QueryRowContext(ctx, `SELECT CAST(s.admin_id AS CHAR),s.session_hash,s.session_version,s.scopes_json,UNIX_TIMESTAMP(s.expires_at)
 FROM chat_admin_sessions s
 WHERE s.id=? AND s.revoked_at IS NULL AND s.expires_at>UTC_TIMESTAMP()
 LIMIT 1`, string(c.SourceID)).Scan(&actor, &sid, &version, &scopesJSON, &expires)
	if err == sql.ErrNoRows {
		return ErrUnauthorized
	}
	if err != nil {
		return ports.ErrUnavailable
	}
	if actor != string(c.ActorID) || sid != c.SessionID || version != c.Version || expires <= time.Now().Unix() || c.ExpiresAt > expires {
		return ErrUnauthorized
	}
	var scopes []string
	if json.Unmarshal([]byte(scopesJSON), &scopes) != nil || !validScopes("admin", scopes) {
		return ErrUnauthorized
	}
	for _, wanted := range c.Scopes {
		found := false
		for _, allowed := range scopes {
			if wanted == allowed {
				found = true
			}
		}
		if !found {
			return ErrUnauthorized
		}
	}
	return nil
}
