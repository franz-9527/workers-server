package message

import (
	"fmt"
	"strings"
	"testing"
	"time"
)

func client(n int) string { return fmt.Sprintf("%d.%032x", time.Now().Unix(), n) }
func request(n int) Request {
	return Request{ConversationID: "1", ClientMessageID: client(n), MessageType: "text", Text: "施工尺寸 3.5m × 2m\n明天见 🛠️"}
}
func TestActionBoundaryAndFingerprint(t *testing.T) {
	now := time.Now().Truncate(time.Second)
	id := fmt.Sprintf("%d.%032x", now.Unix(), 1)
	if !active(id, now.Add(ActionWindow-time.Nanosecond)) || active(id, now.Add(ActionWindow)) || active(id, now.Add(-31*time.Second)) {
		t.Fatal("action window boundary")
	}
	r := request(1)
	fp, e := fingerprint(r)
	if e != nil {
		t.Fatal(e)
	}
	r.Text += " "
	other, _ := fingerprint(r)
	if fp == other {
		t.Fatal("whitespace was normalized")
	}
	r.Text = strings.Repeat("中", 1334)
	if _, e = fingerprint(r); e == nil {
		t.Fatal("UTF8 byte limit")
	}
	for _, id := range []string{"1", client(1) + "0", "0000000000." + strings.Repeat("a", 32), strings.ToUpper(client(255))} {
		r = request(1)
		r.ClientMessageID = id
		if _, e = fingerprint(r); e == nil {
			t.Fatalf("invalid client ID %s", id)
		}
	}
}
func TestStrictJSON(t *testing.T) {
	for _, v := range []string{`"\ud83d\udee0"`, `"�"`, `"\\uD800"`} {
		if !validSurrogates([]byte(v)) {
			t.Fatal("valid Unicode rejected", v)
		}
	}
	for _, v := range []string{`"\ud800"`, `"\udc00"`, `"\ud800\u0041"`} {
		if validSurrogates([]byte(v)) {
			t.Fatal("lossy Unicode accepted", v)
		}
	}

	good := fmt.Sprintf(`{"conversation_id":"18446744073709551615","client_message_id":%q,"message_type":"text","text":"换行\n🛠"}`, client(1))
	if _, e := decode([]byte(good), false); e != nil {
		t.Fatal(e)
	}
	for _, body := range []string{strings.Replace(good, `"text":`, `"text":"x","text":`, 1), strings.Replace(good, `"text":`, `"Text":`, 1), strings.Replace(good, `"message_type":"text"`, `"message_type":null`, 1), strings.Replace(good, `"18446744073709551615"`, `18446744073709551615`, 1), good + `{}`, strings.Replace(good, `换行\n🛠`, `\ud800`, 1), `[]`, strings.Replace(good, `"text":`, `"sender_id":"42","text":`, 1)} {
		if _, e := decode([]byte(body), false); e == nil {
			t.Fatalf("accepted invalid body %s", body)
		}
	}
	if _, e := decode([]byte(good), true); e == nil {
		t.Fatal("query accepted text")
	}
}
