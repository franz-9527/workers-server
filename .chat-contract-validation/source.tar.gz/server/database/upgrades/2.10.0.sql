-- V2.10.0：平台工作人员权限代次及有界授权恢复。PHP单写，Go只读。
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

-- 修复历史新装基线遗漏的平台专属表；已有升级库保持原表及资金数据。
CREATE TABLE IF NOT EXISTS `order_platform_terms` (
  `order_id` bigint(20) unsigned NOT NULL COMMENT '订单ID',
  `customer_flow_mode` varchar(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'platform_managed' COMMENT '客户参与方式：platform_managed平台托管、miniapp_booking小程序预约',
  `customer_pricing_mode` varchar(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'fixed_total' COMMENT '客户计价方式：fixed_total固定总价、itemized明细计价',
  `customer_contract_total_cents` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '客户当前最终成交金额（分）',
  `worker_settlement_mode` varchar(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'worker_collect' COMMENT '师傅工费结算：worker_collect师傅代收、platform_balance平台余额',
  `worker_labor_cents` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '当前最终师傅工费（分）',
  `extra_income_rate_bp_snapshot` int(10) unsigned NOT NULL DEFAULT '2000' COMMENT '订单外加项平台收入比例快照（万分比）',
  `booking_paid_cents` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '最终结算时平台已收预约费快照（分）',
  `customer_tail_cents` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '客户现场剩余应付（分）',
  `platform_receivable_cents` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '平台收入款待收金额（分）',
  `worker_balance_credit_cents` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '应进入师傅余额金额（分）',
  `worker_balance_freeze_days_snapshot` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '师傅余额冻结天数快照',
  `settlement_status` varchar(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'pending' COMMENT '平台承接单结算状态',
  `settled_at` datetime DEFAULT NULL COMMENT '结算完成时间',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`order_id`),
  KEY `idx_platform_terms_settlement` (`settlement_status`,`updated_at`),
  CONSTRAINT `fk_platform_terms_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='V2.5.0 平台承接单专属计价与结算条件';

CREATE TABLE IF NOT EXISTS `order_pricing_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `order_id` bigint(20) unsigned NOT NULL COMMENT '订单ID',
  `item_source` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'base' COMMENT '明细来源：base基础开单、change订单外加项',
  `change_request_id` bigint(20) unsigned DEFAULT NULL COMMENT '关联费用调整申请ID',
  `description` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '施工项目/描述',
  `note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '项目说明',
  `quantity` decimal(12,3) DEFAULT NULL COMMENT '数量/实际用量',
  `unit` varchar(24) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '计价单位',
  `unit_price_cents` bigint(20) unsigned DEFAULT NULL COMMENT '单价（分）',
  `amount_cents` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '项目金额（分）',
  `sort_order` int(11) NOT NULL DEFAULT '0' COMMENT '排序值',
  `status` varchar(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'active' COMMENT '状态',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_pricing_items_order_sort` (`order_id`,`status`,`sort_order`,`id`),
  KEY `idx_pricing_items_change` (`change_request_id`),
  CONSTRAINT `fk_pricing_items_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_pricing_items_change` FOREIGN KEY (`change_request_id`) REFERENCES `change_requests` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='V2.5.0 平台承接单结构化开单明细';

CREATE TABLE IF NOT EXISTS `platform_order_refund_reviews` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '退款财务复核单ID',
  `order_id` bigint(20) unsigned NOT NULL COMMENT '关联平台承接订单ID',
  `refund_id` bigint(20) unsigned NOT NULL COMMENT '原真实退款单ID（一退款只处理一次）',
  `refund_amount_cents` bigint(20) unsigned NOT NULL COMMENT '建档时退款成功金额快照（分）',
  `worker_labor_cents_snapshot` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '验收时师傅工费快照（分）',
  `worker_balance_credit_cents_snapshot` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '验收时实际应入师傅余额快照（分）',
  `status` varchar(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'open' COMMENT 'open待判责、awaiting_recovery待实际追偿、resolved核账结束',
  `responsibility` varchar(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'undetermined' COMMENT 'undetermined待定、platform平台、worker师傅、shared分担',
  `worker_recovery_cents` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '人工判定应由师傅补交金额（分）',
  `recovered_cents` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '已核对真实到账的线下追偿累计金额（分）',
  `decision_note` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '责任判定的事实依据',
  `recovery_reference` varchar(120) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '最近一次已核实的追偿交易流水号（完整逐笔凭证见人工收款台账）',
  `recovery_note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '线下真实追偿核验说明',
  `created_by_admin_id` bigint(20) unsigned DEFAULT NULL COMMENT '发起核账管理员ID',
  `decided_by_admin_id` bigint(20) unsigned DEFAULT NULL COMMENT '判责管理员ID',
  `resolved_by_admin_id` bigint(20) unsigned DEFAULT NULL COMMENT '核实结清管理员ID',
  `created_at` datetime NOT NULL COMMENT '建档时间',
  `decided_at` datetime DEFAULT NULL COMMENT '判责时间',
  `resolved_at` datetime DEFAULT NULL COMMENT '核账结束时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_platform_refund_review_refund` (`refund_id`),
  UNIQUE KEY `uq_platform_refund_review_recovery` (`recovery_reference`),
  KEY `idx_platform_refund_review_order_status` (`order_id`,`status`),
  KEY `idx_platform_refund_review_status_created` (`status`,`created_at`),
  CONSTRAINT `fk_platform_refund_review_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_platform_refund_review_refund` FOREIGN KEY (`refund_id`) REFERENCES `refunds` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='平台单已验收后退款资金判责与线下追偿人工核账';

CREATE TABLE IF NOT EXISTS `platform_order_manual_receipts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '实际外部收款凭证ID',
  `order_id` bigint(20) unsigned NOT NULL COMMENT '所属平台订单',
  `refund_review_id` bigint(20) unsigned DEFAULT NULL COMMENT '追偿对应退款复核单；平台收入款时为空',
  `income_order_id` bigint(20) unsigned DEFAULT NULL COMMENT '仅平台收入款填写的订单ID，唯一防重复核销',
  `receipt_kind` varchar(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'platform_income平台收入款、refund_recovery退款追偿',
  `amount_cents` bigint(20) unsigned NOT NULL COMMENT '本笔人工核验实际到账分数',
  `payment_reference` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '银行或第三方支付实际收款编号；全类型唯一',
  `verification_note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '人工核实凭据及渠道说明',
  `verified_by_admin_id` bigint(20) unsigned DEFAULT NULL COMMENT '核验管理员ID',
  `verified_at` datetime NOT NULL COMMENT '实际核验记录时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_manual_receipt_reference` (`payment_reference`),
  UNIQUE KEY `uq_manual_income_order` (`income_order_id`),
  KEY `idx_manual_receipt_review` (`refund_review_id`,`verified_at`),
  KEY `idx_manual_receipt_order` (`order_id`,`verified_at`),
  CONSTRAINT `fk_manual_receipt_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_manual_receipt_review` FOREIGN KEY (`refund_review_id`) REFERENCES `platform_order_refund_reviews` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='平台外部收款人工核验逐笔凭证，不代表微信支付或钱包入账';

CREATE TABLE IF NOT EXISTS `chat_staff_authority_versions` (
  `user_id` bigint(20) unsigned NOT NULL COMMENT '0为管理员配置，其余为真实用户；删除后保留代次',
  `authority_version` bigint(20) unsigned NOT NULL DEFAULT 1 COMMENT '只增不减，移除再加入不得复用',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='PHP权限源同事务更新，Go取共享锁校验';
INSERT IGNORE INTO `chat_staff_authority_versions` (`user_id`,`authority_version`) VALUES (0,1);
INSERT IGNORE INTO `chat_staff_authority_versions` (`user_id`,`authority_version`) SELECT id,1 FROM users;

CREATE TABLE IF NOT EXISTS `chat_policy_refresh` (
  `order_id` bigint(20) unsigned NOT NULL COMMENT '订单ID，不存消息内容',
  `checked_at` datetime NOT NULL COMMENT '上次检查UTC',
  `next_check_at` datetime NOT NULL COMMENT '下一次可检查UTC',
  `status` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'success或failed',
  PRIMARY KEY (`order_id`),
  KEY `idx_chat_policy_refresh_due` (`next_check_at`,`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='PHP授权投影恢复游标，不承担即时撤权';

-- 单语句触发器，覆盖Web/小程序/CLI/SQL维护，且回滚与原身份写入一致。
DROP TRIGGER IF EXISTS `chat_staff_settings_insert`;
CREATE TRIGGER `chat_staff_settings_insert` AFTER INSERT ON `system_settings`
FOR EACH ROW UPDATE chat_staff_authority_versions SET authority_version=authority_version+1
WHERE user_id=0 AND NEW.setting_key IN ('wechat.admin_openids','wechat.miniapp_appid');
DROP TRIGGER IF EXISTS `chat_staff_settings_update`;
CREATE TRIGGER `chat_staff_settings_update` AFTER UPDATE ON `system_settings`
FOR EACH ROW UPDATE chat_staff_authority_versions SET authority_version=authority_version+1
WHERE user_id=0 AND (OLD.setting_key IN ('wechat.admin_openids','wechat.miniapp_appid') OR NEW.setting_key IN ('wechat.admin_openids','wechat.miniapp_appid'))
AND (NOT (BINARY OLD.setting_key <=> BINARY NEW.setting_key) OR NOT (BINARY OLD.setting_value <=> BINARY NEW.setting_value) OR NOT (BINARY OLD.value_type <=> BINARY NEW.value_type));
DROP TRIGGER IF EXISTS `chat_staff_settings_delete`;
CREATE TRIGGER `chat_staff_settings_delete` AFTER DELETE ON `system_settings`
FOR EACH ROW UPDATE chat_staff_authority_versions SET authority_version=authority_version+1
WHERE user_id=0 AND OLD.setting_key IN ('wechat.admin_openids','wechat.miniapp_appid');
DROP TRIGGER IF EXISTS `chat_staff_user_insert`;
CREATE TRIGGER `chat_staff_user_insert` AFTER INSERT ON `users`
FOR EACH ROW INSERT INTO chat_staff_authority_versions(user_id,authority_version) VALUES(NEW.id,1)
ON DUPLICATE KEY UPDATE authority_version=authority_version+1;
DROP TRIGGER IF EXISTS `chat_staff_user_update`;
CREATE TRIGGER `chat_staff_user_update` AFTER UPDATE ON `users`
FOR EACH ROW UPDATE chat_staff_authority_versions SET authority_version=authority_version+1
WHERE user_id IN (OLD.id,NEW.id) AND (NOT (OLD.id <=> NEW.id) OR NOT (OLD.status <=> NEW.status));
DROP TRIGGER IF EXISTS `chat_staff_user_delete`;
CREATE TRIGGER `chat_staff_user_delete` AFTER DELETE ON `users`
FOR EACH ROW UPDATE chat_staff_authority_versions SET authority_version=authority_version+1 WHERE user_id=OLD.id;
DROP TRIGGER IF EXISTS `chat_staff_wechat_insert`;
CREATE TRIGGER `chat_staff_wechat_insert` AFTER INSERT ON `wechat_identities`
FOR EACH ROW UPDATE chat_staff_authority_versions SET authority_version=authority_version+1 WHERE user_id=NEW.user_id;
DROP TRIGGER IF EXISTS `chat_staff_wechat_update`;
CREATE TRIGGER `chat_staff_wechat_update` AFTER UPDATE ON `wechat_identities`
FOR EACH ROW UPDATE chat_staff_authority_versions SET authority_version=authority_version+1
WHERE user_id IN (OLD.user_id,NEW.user_id)
AND (NOT (OLD.user_id <=> NEW.user_id) OR NOT (OLD.app_id <=> NEW.app_id) OR NOT (OLD.openid <=> NEW.openid) OR NOT (OLD.status <=> NEW.status));
DROP TRIGGER IF EXISTS `chat_staff_wechat_delete`;
CREATE TRIGGER `chat_staff_wechat_delete` AFTER DELETE ON `wechat_identities`
FOR EACH ROW UPDATE chat_staff_authority_versions SET authority_version=authority_version+1 WHERE user_id=OLD.user_id;
