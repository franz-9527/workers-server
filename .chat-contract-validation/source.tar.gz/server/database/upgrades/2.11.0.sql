-- V2.11.0：Go单写会话/成员权限版本区间与事件租约；不创建消息或启用聊天。
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `chat_conversations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '独立会话ID，不等于订单ID',
  `conversation_type` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '当前仅order',
  `scope_key` varchar(96) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'PHP提供的不可变订单指派作用域',
  `order_id` bigint(20) unsigned NOT NULL COMMENT '可信订单绑定，不直接授予权限',
  `assignment_id` bigint(20) unsigned NOT NULL COMMENT '不可变指派绑定',
  `policy_version` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '已连续应用的PHP权限版本',
  `snapshot_hash` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '已应用快照指纹',
  `episode_key` varchar(96) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'PHP授权业务区间代次',
  `state` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'open或readonly；pending仅事务内',
  `created_at` datetime(6) NOT NULL COMMENT '建立时间UTC',
  `updated_at` datetime(6) NOT NULL COMMENT '投影更新时间UTC，不是消息活跃时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_chat_conversation_scope` (`conversation_type`,`scope_key`),
  UNIQUE KEY `uq_chat_conversation_binding` (`conversation_type`,`order_id`,`assignment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Go单写独立会话与可信业务绑定';

CREATE TABLE IF NOT EXISTS `chat_members` (
  `conversation_id` bigint(20) unsigned NOT NULL COMMENT '所属会话ID',
  `actor_id` bigint(20) unsigned NOT NULL COMMENT '真实用户ID，当前仅小程序身份',
  `actor_kind` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '当前仅mini，不接受后台审计成员',
  `role` varchar(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'customer/worker/platform_staff',
  `member_key` varchar(240) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '包含episode和工作人员配置/用户代次',
  `can_read` tinyint(1) NOT NULL COMMENT '最近应用快照的读取资格，仍需当前栅栏交集',
  `can_send` tinyint(1) NOT NULL COMMENT '最近应用快照的发送资格，仍需当前栅栏交集',
  PRIMARY KEY (`conversation_id`,`actor_id`),
  KEY `idx_chat_member_actor` (`actor_id`,`can_read`,`conversation_id`),
  CONSTRAINT `fk_chat_member_conversation` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Go单写当前成员投影，不复制用户账号';

CREATE TABLE IF NOT EXISTS `chat_member_intervals` (
  `conversation_id` bigint(20) unsigned NOT NULL COMMENT '所属会话ID',
  `actor_id` bigint(20) unsigned NOT NULL COMMENT '真实用户ID',
  `member_key` varchar(240) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '不可变授权身份代次',
  `start_version` bigint(20) unsigned NOT NULL COMMENT '可读消息权限版本下界，包含',
  `end_version` bigint(20) unsigned DEFAULT NULL COMMENT '可读消息权限版本上界，不包含；空表示尚未闭合',
  `open_actor_id` bigint(20) unsigned GENERATED ALWAYS AS (IF(`end_version` IS NULL,`actor_id`,NULL)) STORED COMMENT '每会话每人最多一个未闭合区间',
  PRIMARY KEY (`conversation_id`,`actor_id`,`start_version`),
  UNIQUE KEY `uq_chat_interval_open` (`conversation_id`,`open_actor_id`),
  CONSTRAINT `fk_chat_interval_conversation` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Go单写历史授权版本区间，禁止用处理时seq补权';

CREATE TABLE IF NOT EXISTS `chat_event_receipts` (
  `event_id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'PHP原始不可变事件ID',
  `aggregate_key` varchar(96) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '原始会话作用域',
  `aggregate_version` bigint(20) unsigned NOT NULL COMMENT '原始PHP权限版本',
  `payload_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '领取时原始事件指纹',
  `status` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'processing/retry/done/rejected',
  `attempts` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '领取次数，有界递增',
  `lease_owner` char(32) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL COMMENT '每次领取随机独立所有者',
  `lease_until` datetime(6) DEFAULT NULL COMMENT '服务端租约截止UTC',
  `next_attempt_at` datetime(6) NOT NULL COMMENT '失败退避后可重试时间UTC',
  `error_code` varchar(48) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL COMMENT '稳定诊断码，不存正文或SQL',
  `completed_at` datetime(6) DEFAULT NULL COMMENT '与会话投影同事务完成UTC',
  PRIMARY KEY (`event_id`),
  UNIQUE KEY `uq_chat_receipt_scope_version` (`aggregate_key`,`aggregate_version`),
  KEY `idx_chat_receipt_retry` (`status`,`next_attempt_at`),
  KEY `idx_chat_receipt_lease` (`status`,`lease_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Go单写消费回执/租约，PHP事件表只读';
