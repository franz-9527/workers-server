-- V2.12.0：S06文字发送事务基础；仅隔离测试，真实审核未就绪，禁止开放生产发送。
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

SET @chat_s06_ddl = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='chat_conversations' AND COLUMN_NAME='last_seq')=0, 'ALTER TABLE `chat_conversations` ADD COLUMN `last_seq` bigint(20) unsigned NOT NULL DEFAULT ''0'' COMMENT ''同会话已提交封闭消息高水位''', 'SELECT 1');
PREPARE chat_s06_stmt FROM @chat_s06_ddl;
EXECUTE chat_s06_stmt;
DEALLOCATE PREPARE chat_s06_stmt;

SET @chat_s06_ddl = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='chat_conversations' AND COLUMN_NAME='last_change_seq')=0, 'ALTER TABLE `chat_conversations` ADD COLUMN `last_change_seq` bigint(20) unsigned NOT NULL DEFAULT ''0'' COMMENT ''同会话已提交封闭变更高水位''', 'SELECT 1');
PREPARE chat_s06_stmt FROM @chat_s06_ddl;
EXECUTE chat_s06_stmt;
DEALLOCATE PREPARE chat_s06_stmt;

SET @chat_s06_ddl = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='chat_conversations' AND COLUMN_NAME='last_message_id')=0, 'ALTER TABLE `chat_conversations` ADD COLUMN `last_message_id` bigint(20) unsigned DEFAULT NULL COMMENT ''最后正式消息ID，无待审占位''', 'SELECT 1');
PREPARE chat_s06_stmt FROM @chat_s06_ddl;
EXECUTE chat_s06_stmt;
DEALLOCATE PREPARE chat_s06_stmt;

SET @chat_s06_ddl = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='chat_conversations' AND COLUMN_NAME='last_message_at')=0, 'ALTER TABLE `chat_conversations` ADD COLUMN `last_message_at` datetime(6) DEFAULT NULL COMMENT ''最后正式消息提交UTC''', 'SELECT 1');
PREPARE chat_s06_stmt FROM @chat_s06_ddl;
EXECUTE chat_s06_stmt;
DEALLOCATE PREPARE chat_s06_stmt;

CREATE TABLE IF NOT EXISTS `chat_restrictions` (
  `actor_id` bigint(20) unsigned NOT NULL COMMENT '真实mini用户ID，永久稳定锁行，不得删除',
  `permanent` tinyint(1) NOT NULL DEFAULT '0' COMMENT '永久禁发；不限制合法查询与原业务',
  `blocked_until` datetime(6) DEFAULT NULL COMMENT '限时禁发截止UTC，空且非永久表示未限制',
  `version` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '限制变更单调代次，后续管理写入需递增',
  `updated_at` datetime(6) NOT NULL COMMENT '限制更新时间UTC',
  PRIMARY KEY (`actor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Go单写账号发送限制与稳定锁，不能按有无禁令加锁';

CREATE TABLE IF NOT EXISTS `chat_send_intents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '服务端发送意图ID',
  `sender_id` bigint(20) unsigned NOT NULL COMMENT '真实mini发送者ID',
  `conversation_id` bigint(20) unsigned NOT NULL COMMENT '授权会话ID',
  `client_message_id` varchar(43) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '10位Unix秒点32位小写hex随机数，不随重试变化',
  `fingerprint` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '版本化完整正文结构SHA256，不存被拒绝正文',
  `state` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'checking/retryable/rejected/accepted',
  `error_code` varchar(48) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL COMMENT '安全稳定诊断码，无规则证据',
  `message_id` bigint(20) unsigned DEFAULT NULL COMMENT '已提交正式消息ID，拒绝为空',
  `lease_owner` char(32) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL COMMENT '当前检查随机所有者，旧所有者不能发布',
  `lease_until` datetime(6) DEFAULT NULL COMMENT '10秒有界审核所有权截止UTC',
  `attempts` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '最多8次检查尝试，耗尽不自动换ID补发',
  `action_expires_at` datetime(6) NOT NULL COMMENT 'ID创建秒加24小时，发布前再次校验',
  `retain_until` datetime(6) NOT NULL COMMENT '至少动作截止后30天；独立于正文TTL，本阶段不清理',
  `created_at` datetime(6) NOT NULL COMMENT '首次创建UTC',
  `updated_at` datetime(6) NOT NULL COMMENT '状态更新时间UTC',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_chat_send_client` (`sender_id`,`conversation_id`,`client_message_id`),
  KEY `idx_chat_send_pending` (`sender_id`,`state`,`lease_until`),
  KEY `idx_chat_send_retention` (`retain_until`),
  CONSTRAINT `fk_chat_send_conversation` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Go单写发送意图与最小幂等结果，审核中不占消息seq';

CREATE TABLE IF NOT EXISTS `chat_messages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '独立正式消息ID，对外字符串',
  `conversation_id` bigint(20) unsigned NOT NULL COMMENT '所属会话ID',
  `seq` bigint(20) unsigned NOT NULL COMMENT '会话锁内按提交顺序分配，拒绝不占号',
  `sender_id` bigint(20) unsigned NOT NULL COMMENT '真实mini发送者ID',
  `client_message_id` varchar(43) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '原客户端动作ID',
  `policy_version` bigint(20) unsigned NOT NULL COMMENT '最终提交时PHP权限版本，不可回填改写',
  `message_type` varchar(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '本阶段仅text',
  `text_body` text COLLATE utf8mb4_unicode_ci COMMENT '原始UTF8正文，普通查询必须按安全状态过滤',
  `state` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'published/recalled/blocked，普通结果不返回正文',
  `state_version` bigint(20) unsigned NOT NULL DEFAULT '1' COMMENT '安全状态单调版本',
  `safety_rule_version` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '通过必需审核的版本',
  `created_at` datetime(6) NOT NULL COMMENT '正式发布UTC',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_chat_message_seq` (`conversation_id`,`seq`),
  UNIQUE KEY `uq_chat_message_client` (`sender_id`,`conversation_id`,`client_message_id`),
  CONSTRAINT `fk_chat_message_conversation` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Go单写已提交消息，无审核占位，历史按权限版本裁剪';

CREATE TABLE IF NOT EXISTS `chat_message_changes` (
  `conversation_id` bigint(20) unsigned NOT NULL COMMENT '所属会话ID',
  `change_seq` bigint(20) unsigned NOT NULL COMMENT '会话共享提交锁内分配的封闭变更游标',
  `message_id` bigint(20) unsigned NOT NULL COMMENT '变更所属正式消息ID',
  `state_version` bigint(20) unsigned NOT NULL COMMENT '消息安全状态版本',
  `change_type` varchar(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '当前message.accepted，后续撤回等同事务追加',
  `created_at` datetime(6) NOT NULL COMMENT '提交UTC',
  PRIMARY KEY (`conversation_id`,`change_seq`),
  CONSTRAINT `fk_chat_change_conversation` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`),
  CONSTRAINT `fk_chat_change_message` FOREIGN KEY (`message_id`) REFERENCES `chat_messages` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Go单写消息安全变更，S08再接同步分页接口';
