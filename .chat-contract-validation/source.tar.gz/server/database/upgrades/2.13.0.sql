-- V2.13.0：S07文本审核短窗口、去重与受控风险证据；真实发送仍关闭。
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

SET @chat_s07_ddl=IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='chat_send_intents' AND COLUMN_NAME='risk_event_id')=0,'ALTER TABLE `chat_send_intents` ADD COLUMN `risk_event_id` bigint(20) unsigned DEFAULT NULL COMMENT ''风险或疑似复核事件ID，仅本人最小结果返回，不展开证据''','SELECT 1');
PREPARE chat_s07_stmt FROM @chat_s07_ddl;
EXECUTE chat_s07_stmt;
DEALLOCATE PREPARE chat_s07_stmt;

CREATE TABLE IF NOT EXISTS `chat_text_checks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '短窗口检查顺序，同作者稳定锁内登记',
  `intent_id` bigint(20) unsigned NOT NULL COMMENT '逻辑发送动作ID，重试不追加片段',
  `sender_id` bigint(20) unsigned NOT NULL COMMENT '真实mini发送者ID',
  `conversation_id` bigint(20) unsigned NOT NULL COMMENT '仅限本会话上下文，不跨群跟踪',
  `fingerprint` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '完整不可变发送内容指纹',
  `normalized_text` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '受限业务短窗口证据，不进入普通日志或普通API',
  `cache_key` char(64) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL COMMENT '环境AppID身份代次场景规则及指纹联合去重键',
  `pass_until` datetime(6) DEFAULT NULL COMMENT '仅明确官方pass缓存五分钟，不延长原判定',
  `created_at` datetime(6) NOT NULL COMMENT '首次动作登记UTC，重试不刷新窗口',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_chat_text_intent` (`intent_id`),
  KEY `idx_chat_text_context` (`sender_id`,`conversation_id`,`created_at`,`id`),
  KEY `idx_chat_text_pass` (`cache_key`,`pass_until`),
  KEY `idx_chat_text_expiry` (`created_at`),
  CONSTRAINT `fk_chat_text_intent` FOREIGN KEY (`intent_id`) REFERENCES `chat_send_intents` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Go单写两分钟最近五动作检测，十分钟后有界清理';

CREATE TABLE IF NOT EXISTS `chat_risk_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '独立风险事件ID，仅作者安全结果可引用',
  `intent_id` bigint(20) unsigned NOT NULL COMMENT '逻辑发送动作唯一，不因重试累计违规',
  `sender_id` bigint(20) unsigned NOT NULL COMMENT '真实mini发送者ID',
  `conversation_id` bigint(20) unsigned NOT NULL COMMENT '原会话ID',
  `content_fingerprint` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '原始完整内容结构指纹',
  `rule_version` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '完整检测规则版本',
  `provider` varchar(48) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '官方内容安全或本地私单检测来源',
  `reason_code` varchar(48) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '稳定规则码，不向普通接口输出命中详情',
  `provider_trace` varchar(128) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '受限供应商追踪标识，不存整包响应',
  `risk_level` tinyint(3) unsigned NOT NULL COMMENT '1疑似待复核，2明确拦截；不直接作财务处置',
  `confirmed` tinyint(1) NOT NULL COMMENT '仅明确拦截记确认风险；审核故障不建风险',
  `disposition` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'rejected或review_pending，不自动补发',
  `review_state` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'open' COMMENT 'S19复核接续状态，当前无处理接口',
  `text_evidence` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '原文只在受控业务证据中，未来独立权限审计读取',
  `context_evidence` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '仅拆条命中的有界上下文，含动作ID指纹和规范化片段；普通接口不展开',
  `retain_until` datetime(6) NOT NULL COMMENT '至少覆盖原动作最小结果保留窗，当前不清理证据',
  `created_at` datetime(6) NOT NULL COMMENT '与发送者终态同事务提交UTC',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_chat_risk_intent` (`intent_id`),
  KEY `idx_chat_risk_actor` (`sender_id`,`confirmed`,`created_at`),
  KEY `idx_chat_risk_review` (`review_state`,`created_at`,`id`),
  CONSTRAINT `fk_chat_risk_intent` FOREIGN KEY (`intent_id`) REFERENCES `chat_send_intents` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Go单写风险证据和复核接续；普通API不返回原文，不自动罚款封号';
