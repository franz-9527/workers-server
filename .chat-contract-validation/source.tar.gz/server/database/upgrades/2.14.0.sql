-- V2.14.0：S08双游标保留边界；仅Go在同一会话提交锁内推进，不执行历史清理。
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

SET @chat_s08_ddl = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='chat_conversations' AND COLUMN_NAME='sync_floor_seq')=0, 'ALTER TABLE `chat_conversations` ADD COLUMN `sync_floor_seq` bigint(20) unsigned NOT NULL DEFAULT ''0'' COMMENT ''消息补收已清理范围上界，不含可补收起点''', 'SELECT 1');
PREPARE chat_s08_stmt FROM @chat_s08_ddl;
EXECUTE chat_s08_stmt;
DEALLOCATE PREPARE chat_s08_stmt;

SET @chat_s08_ddl = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='chat_conversations' AND COLUMN_NAME='change_floor_seq')=0, 'ALTER TABLE `chat_conversations` ADD COLUMN `change_floor_seq` bigint(20) unsigned NOT NULL DEFAULT ''0'' COMMENT ''安全变更已清理范围上界，不含可补收起点''', 'SELECT 1');
PREPARE chat_s08_stmt FROM @chat_s08_ddl;
EXECUTE chat_s08_stmt;
DEALLOCATE PREPARE chat_s08_stmt;

