-- V2.7.0：聊天身份桥接。PHP单写，Go仅SELECT；不会自动启用聊天或产生消息。
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `chat_admin_sessions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '聊天后台会话ID',
  `admin_id` bigint(20) unsigned NOT NULL COMMENT '原后台管理员ID',
  `session_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '环境绑定的PHP Session摘要',
  `session_version` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '随机会话撤销版本',
  `authority_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '角色密码及scope快照摘要',
  `scopes_json` varchar(128) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '限权scope JSON数组',
  `expires_at` datetime NOT NULL COMMENT '最晚凭证到期时间UTC',
  `revoked_at` datetime DEFAULT NULL COMMENT '原Session登出或撤销时间UTC',
  `created_at` datetime NOT NULL COMMENT '创建时间UTC',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_chat_admin_session_hash` (`session_hash`),
  KEY `idx_chat_admin_actor_expiry` (`admin_id`,`expires_at`),
  KEY `idx_chat_admin_expiry` (`expires_at`),
  CONSTRAINT `fk_chat_admin_actor` FOREIGN KEY (`admin_id`) REFERENCES `admin_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='PHP后台聊天凭证会话，Go只读';

-- 同步撤销所有PHP账号写入口（含SQL维护）；不向Go授予后台密码表读取权限。
-- 单语句trigger，无DELIMITER/BEGIN语法；原账号修改与撤销属于同一MySQL事务。
DROP TRIGGER IF EXISTS `chat_admin_identity_revoke`;
CREATE TRIGGER `chat_admin_identity_revoke` AFTER UPDATE ON `admin_users`
FOR EACH ROW UPDATE `chat_admin_sessions`
SET `revoked_at`=COALESCE(`revoked_at`,UTC_TIMESTAMP())
WHERE `admin_id`=NEW.id AND `revoked_at` IS NULL
  AND (NOT (OLD.role <=> NEW.role) OR NOT (OLD.status <=> NEW.status)
       OR NOT (OLD.password_hash <=> NEW.password_hash)
       OR NOT (OLD.must_change_password <=> NEW.must_change_password));
