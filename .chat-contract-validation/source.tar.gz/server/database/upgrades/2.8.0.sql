-- V2.8.0：PHP订单聊天授权栅栏与低频事件。尚未接齐业务入口，不自动启用/回填。
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `chat_policy_guards` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '栅栏ID',
  `scope_key` varchar(96) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '订单与不可变指派代次',
  `order_id` bigint(20) unsigned NOT NULL COMMENT '订单ID',
  `assignment_id` bigint(20) unsigned NOT NULL COMMENT '不可变指派ID',
  `policy_version` bigint(20) unsigned NOT NULL COMMENT '同scope单调权限版本',
  `state` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'open可发或readonly只读',
  `active_order_id` bigint(20) unsigned GENERATED ALWAYS AS (IF(`state`='open',`order_id`,NULL)) STORED COMMENT '同订单仅一个可发scope',
  `snapshot_json` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'PHP权威身份与授权区间快照',
  `snapshot_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '无版本快照指纹用于幂等',
  `updated_at` datetime NOT NULL COMMENT '更新时间UTC',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_chat_policy_scope` (`scope_key`),
  UNIQUE KEY `uq_chat_policy_active_order` (`active_order_id`),
  KEY `idx_chat_policy_order` (`order_id`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='PHP单写订单聊天权限栅栏，Go只读和取共享锁';

CREATE TABLE IF NOT EXISTS `chat_business_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '扫描定位ID，不等于已提交水位',
  `event_id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '随机稳定业务事件ID',
  `aggregate_key` varchar(96) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '会话作用域',
  `aggregate_version` bigint(20) unsigned NOT NULL COMMENT '该scope权限版本',
  `schema_version` int(10) unsigned NOT NULL COMMENT '事件协议版本',
  `event_type` varchar(48) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '事件类型',
  `payload_json` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '版本化完整授权快照',
  `created_at` datetime NOT NULL COMMENT '提交时间UTC',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_chat_business_event` (`event_id`),
  UNIQUE KEY `uq_chat_business_scope_version` (`aggregate_key`,`aggregate_version`),
  KEY `idx_chat_business_created` (`created_at`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='PHP订单事务事件，Go不修改消费状态';
