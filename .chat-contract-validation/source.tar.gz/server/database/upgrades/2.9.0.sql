-- V2.9.0：售后明确受理事实；仅记录，不自动回填或开放聊天。
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `chat_repair_episodes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '不可变售后受理代次',
  `order_id` bigint(20) unsigned NOT NULL COMMENT '订单ID',
  `assignment_id` bigint(20) unsigned NOT NULL COMMENT '受理时不可变指派ID',
  `after_sale_id` bigint(20) unsigned NOT NULL COMMENT '售后申请ID',
  `worker_id` bigint(20) unsigned NOT NULL COMMENT '明确受理的师傅ID',
  `accepted_user_id` bigint(20) unsigned NOT NULL COMMENT '师傅对应真实小程序用户ID',
  `state` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'active或closed，closed不复活',
  `active_order_id` bigint(20) unsigned GENERATED ALWAYS AS (IF(`state`='active',`order_id`,NULL)) STORED COMMENT '同订单仅一个有效受理区间',
  `accepted_at` datetime NOT NULL COMMENT '原受理事务内UTC时间',
  `closed_at` datetime DEFAULT NULL COMMENT '结束UTC时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_chat_repair_active_order` (`active_order_id`),
  KEY `idx_chat_repair_request` (`order_id`,`after_sale_id`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='PHP单写售后明确受理事实，不从processing或事件文字推断授权';
