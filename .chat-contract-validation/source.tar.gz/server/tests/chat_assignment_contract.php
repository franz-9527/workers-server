<?php

declare(strict_types=1);

use WorkerAdmin\Core\Database;
use WorkerAdmin\Infrastructure\Persistence\DatabaseAdminWorkbenchOperationsRepository;
use WorkerAdmin\Infrastructure\Persistence\DatabaseOrderConversationBridge;
use WorkerAdmin\Infrastructure\Persistence\DatabaseOrderQuoteSwitchRepository;
use WorkerAdmin\Infrastructure\Scheduling\AssignmentTimeoutProcessor;
use WorkerAdmin\Support\SqlScriptRunner;

// Config/id helpers are fixture ports; business repositories, schema and SQL are real.
function public_id(): string{return strtoupper(bin2hex(random_bytes(13)));}
function setting($key,$default=null){return $default;}

/** Called only by chat_policy_contract.php with its explicit loopback test config. */
function chatAssignmentContract(array $config): void
{
    policyAssert($config['host']==='127.0.0.1' && strpos($config['database'],'bixuan_test_policy_')===0,'assignment fixture boundary');
    $config['database']='mysql';$admin=new Database($config);
    $name='bixuan_test_policy_assignment_'.bin2hex(random_bytes(5));
    $admin->execute('CREATE DATABASE `'.$name.'` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
    $config['database']=$name;$db=new Database($config);
    try {
        (new SqlScriptRunner())->runFile($db->pdo(),dirname(__DIR__).'/database/database.sql');
        foreach([10001,10002,10003,10004] as $id)$db->execute("INSERT INTO users(id,public_id,status,created_at,updated_at) VALUES(:id,:public_id,'active',UTC_TIMESTAMP(),UTC_TIMESTAMP())",['id'=>$id,'public_id'=>public_id()]);
        foreach([10=>10002,20=>10003] as $worker=>$user)$db->execute("INSERT INTO worker_profiles(id,user_id,public_id,display_name,verification_status,created_at,updated_at) VALUES(:id,:user_id,:public_id,'fixture','approved',UTC_TIMESTAMP(),UTC_TIMESTAMP())",['id'=>$worker,'user_id'=>$user,'public_id'=>public_id()]);
        $db->execute("INSERT INTO orders(id,public_no,user_id,audit_status,lifecycle_status,payment_status,assignment_status,final_amount_cents,booking_fee_cents,created_at,updated_at) VALUES(77,'CHAT-ASG',10001,'approved','active','paid','accepted',20000,5000,UTC_TIMESTAMP(),UTC_TIMESTAMP())");
        $rule=$db->insert("INSERT INTO commission_rule_versions(order_id,version_no,rate_bp,min_fee_cents,status,created_at) VALUES(77,1,1000,1000,'active',UTC_TIMESTAMP())");
        $db->execute("INSERT INTO assignments(id,public_id,order_id,worker_id,assignment_type,commission_rule_version_id,final_amount_cents_snapshot,booking_fee_cents_snapshot,commission_rate_bp_snapshot,commission_min_cents_snapshot,estimated_commission_cents,estimated_offline_collect_cents,estimated_net_income_cents,status,offered_at,accepted_at,created_at,updated_at) VALUES(100,:public_id,77,10,'admin',:rule,20000,5000,1000,1000,2000,15000,18000,'accepted',UTC_TIMESTAMP(),UTC_TIMESTAMP(),UTC_TIMESTAMP(),UTC_TIMESTAMP())",['public_id'=>public_id(),'rule'=>$rule]);
        $db->execute("UPDATE orders SET current_assignment_id=100,assigned_worker_id=10,commission_rule_version_id=:rule WHERE id=77",['rule'=>$rule]);
        $db->execute("INSERT INTO order_role_grants(order_id,user_id,grant_type,status,created_at) VALUES(77,10002,'assignment','active',UTC_TIMESTAMP())");
        $bridge=new DatabaseOrderConversationBridge($db,true);
        $db->transaction(static function()use($bridge):void{$bridge->synchronize(77);});
        $workbench=new DatabaseAdminWorkbenchOperationsRepository($db);
        $workbench->reassignWorker(['user_id'=>10004],'CHAT-ASG',20,'fixture reassign');
        $offered=(int)$db->fetchValue('SELECT current_assignment_id FROM orders WHERE id=77');
        policyAssert($offered!==100 && $db->fetchValue('SELECT status FROM assignments WHERE id=100')==='cancelled','actual admin reassign creates a new assignment');
        policyAssert($db->fetchValue('SELECT state FROM chat_policy_guards WHERE assignment_id=100')==='readonly','admin reassign immediately closes old worker chat');
        policyAssert((int)$db->fetchValue("SELECT COUNT(*) FROM chat_policy_guards WHERE state='open'")===0,'new offered worker has no chat grant');
        policyAssert($db->fetchValue("SELECT status FROM order_role_grants WHERE order_id=77 AND user_id=10002")==='revoked','original order access revocation retained');
        $quote=$db->insert("INSERT INTO quotes(public_id,order_id,quote_type,worker_id,amount_cents,booking_fee_cents,status,current_version,created_at,updated_at) VALUES(:public_id,77,'worker',10,20000,5000,'active',1,UTC_TIMESTAMP(),UTC_TIMESTAMP())",['public_id'=>public_id()]);
        $db->insert("INSERT INTO quote_versions(quote_id,version_no,amount_cents,booking_fee_cents,commission_rate_bp_snapshot,commission_min_cents_snapshot,rule_acknowledged_at,operator_type,created_at) VALUES(:quote,1,20000,5000,1000,1000,UTC_TIMESTAMP(),'worker',UTC_TIMESTAMP())",['quote'=>$quote]);
        $db->insert("INSERT INTO payment_orders(public_no,business_type,business_id,order_id,payer_user_id,amount_cents,status,created_at,updated_at) VALUES('CHAT-PAY','order_booking',77,77,10001,5000,'paid',UTC_TIMESTAMP(),UTC_TIMESTAMP())");
        $quotePublic=(string)$db->fetchValue('SELECT public_id FROM quotes WHERE id=:id',['id'=>$quote]);
        $switch=new DatabaseOrderQuoteSwitchRepository($db);
        $count=(int)$db->fetchValue('SELECT COUNT(*) FROM assignments');
        $db->execute("CREATE TRIGGER fixture_switch_event_failure BEFORE INSERT ON chat_business_events FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='fixture'");
        $failed=false;try{$switch->switchWorker(['user_id'=>10001],'CHAT-ASG',$quotePublic,'fixture');}catch(PDOException $error){$failed=($error->errorInfo[1]??0)===1644;}
        $db->execute('DROP TRIGGER fixture_switch_event_failure');
        policyAssert($failed && (int)$db->fetchValue('SELECT current_assignment_id FROM orders WHERE id=77')===$offered,'guard failure rolls actual customer switch back');
        policyAssert((int)$db->fetchValue('SELECT COUNT(*) FROM assignments')===$count && $db->fetchValue('SELECT status FROM assignments WHERE id=:id',['id'=>$offered])==='offered','failed switch preserves assignment history and current offer');
        $switch->switchWorker(['user_id'=>10001],'CHAT-ASG',$quotePublic,'fixture');
        $current=(int)$db->fetchValue('SELECT current_assignment_id FROM orders WHERE id=77');
        policyAssert($current!==100 && $current!==$offered && $db->fetchValue('SELECT state FROM chat_policy_guards WHERE assignment_id=:id',['id'=>$current])==='open','same original worker returns on independent accepted scope');
        policyAssert($db->fetchValue('SELECT state FROM chat_policy_guards WHERE assignment_id=100')==='readonly','returning worker never reopens original scope');
        policyAssert((int)$db->fetchValue("SELECT COUNT(*) FROM chat_policy_guards WHERE state='open'")===1,'only one active assignment scope');
        $workbench->reassignWorker(['user_id'=>10004],'CHAT-ASG',20,'fixture timeout');
        $expiring=(int)$db->fetchValue('SELECT current_assignment_id FROM orders WHERE id=77');
        $db->execute('UPDATE assignments SET accept_deadline_at=DATE_SUB(UTC_TIMESTAMP(),INTERVAL 1 HOUR) WHERE id=:id',['id'=>$expiring]);
        policyAssert((new AssignmentTimeoutProcessor($db))->expireProduction($expiring),'actual production timeout executes');
        policyAssert($db->fetchValue('SELECT current_assignment_id FROM orders WHERE id=77')===null && $db->fetchValue('SELECT status FROM assignments WHERE id=:id',['id'=>$expiring])==='expired','timeout clears current assignment');
        policyAssert((int)$db->fetchValue("SELECT COUNT(*) FROM chat_policy_guards WHERE state='open'")===0,'timeout never invents a grant');
        echo "完整新装库的真实管理员改派、客户换回、故障回滚与指派超时验证通过\n";
    } finally {$admin->execute('DROP DATABASE IF EXISTS `'.$name.'`');}
}
