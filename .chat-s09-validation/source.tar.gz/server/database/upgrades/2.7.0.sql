-- V2.7.0：从已发布2.6.0升级的聊天整包；S01～S09共用一个未发布版本。
-- 不开启功能、不回填订单、不发送通知；DDL失败保持维护态，不自动整段重跑。

-- CHAT_SECTION identity
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `chat_admin_sessions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '聊天后台会话ID',
  `admin_id` bigint(20) unsigned NOT NULL COMMENT '原后台管理员ID',
  `session_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '环境绑定的PHP Session摘要',
  `session_version` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '随机会话撤销版本',
  `authority_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '角色密码及scope快照摘要',
  `scopes_json` varchar(128) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '限权scope JSON数组',
  `expires_at` datetime NOT NULL COMMENT '最晚凭证到期时间UTC',
  `revoked_at` datetime DEFAULT NULL COMMENT '原Session登出或撤销时间UTC',
  `created_at` datetime NOT NULL COMMENT '创建时间UTC',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_chat_admin_session_hash` (`session_hash`),
  KEY `idx_chat_admin_actor_expiry` (`admin_id`,`expires_at`),
  KEY `idx_chat_admin_expiry` (`expires_at`),
  CONSTRAINT `fk_chat_admin_actor` FOREIGN KEY (`admin_id`) REFERENCES `admin_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='PHP后台聊天凭证会话，Go只读';

-- 同步撤销所有PHP账号写入口（含SQL维护）；不向Go授予后台密码表读取权限。
-- 单语句trigger，无DELIMITER/BEGIN语法；原账号修改与撤销属于同一MySQL事务。
DROP TRIGGER IF EXISTS `chat_admin_identity_revoke`;
CREATE TRIGGER `chat_admin_identity_revoke` AFTER UPDATE ON `admin_users`
FOR EACH ROW UPDATE `chat_admin_sessions`
SET `revoked_at`=COALESCE(`revoked_at`,UTC_TIMESTAMP())
WHERE `admin_id`=NEW.id AND `revoked_at` IS NULL
  AND (NOT (OLD.role <=> NEW.role) OR NOT (OLD.status <=> NEW.status)
       OR NOT (OLD.password_hash <=> NEW.password_hash)
       OR NOT (OLD.must_change_password <=> NEW.must_change_password));
-- CHAT_END identity

-- CHAT_SECTION policy
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `chat_policy_guards` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '栅栏ID',
  `scope_key` varchar(96) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '订单与不可变指派代次',
  `order_id` bigint(20) unsigned NOT NULL COMMENT '订单ID',
  `assignment_id` bigint(20) unsigned NOT NULL COMMENT '不可变指派ID',
  `policy_version` bigint(20) unsigned NOT NULL COMMENT '同scope单调权限版本',
  `state` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'open可发或readonly只读',
  `active_order_id` bigint(20) unsigned GENERATED ALWAYS AS (IF(`state`='open',`order_id`,NULL)) STORED COMMENT '同订单仅一个可发scope',
  `snapshot_json` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'PHP权威身份与授权区间快照',
  `snapshot_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '无版本快照指纹用于幂等',
  `updated_at` datetime NOT NULL COMMENT '更新时间UTC',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_chat_policy_scope` (`scope_key`),
  UNIQUE KEY `uq_chat_policy_active_order` (`active_order_id`),
  KEY `idx_chat_policy_order` (`order_id`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='PHP单写订单聊天权限栅栏，Go只读和取共享锁';

CREATE TABLE IF NOT EXISTS `chat_business_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '扫描定位ID，不等于已提交水位',
  `event_id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '随机稳定业务事件ID',
  `aggregate_key` varchar(96) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '会话作用域',
  `aggregate_version` bigint(20) unsigned NOT NULL COMMENT '该scope权限版本',
  `schema_version` int(10) unsigned NOT NULL COMMENT '事件协议版本',
  `event_type` varchar(48) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '事件类型',
  `payload_json` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '版本化完整授权快照',
  `created_at` datetime NOT NULL COMMENT '提交时间UTC',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_chat_business_event` (`event_id`),
  UNIQUE KEY `uq_chat_business_scope_version` (`aggregate_key`,`aggregate_version`),
  KEY `idx_chat_business_created` (`created_at`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='PHP订单事务事件，Go不修改消费状态';
-- CHAT_END policy

-- CHAT_SECTION repair
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `chat_repair_episodes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '不可变售后受理代次',
  `order_id` bigint(20) unsigned NOT NULL COMMENT '订单ID',
  `assignment_id` bigint(20) unsigned NOT NULL COMMENT '受理时不可变指派ID',
  `after_sale_id` bigint(20) unsigned NOT NULL COMMENT '售后申请ID',
  `worker_id` bigint(20) unsigned NOT NULL COMMENT '明确受理的师傅ID',
  `accepted_user_id` bigint(20) unsigned NOT NULL COMMENT '师傅对应真实小程序用户ID',
  `state` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'active或closed，closed不复活',
  `active_order_id` bigint(20) unsigned GENERATED ALWAYS AS (IF(`state`='active',`order_id`,NULL)) STORED COMMENT '同订单仅一个有效受理区间',
  `accepted_at` datetime NOT NULL COMMENT '原受理事务内UTC时间',
  `closed_at` datetime DEFAULT NULL COMMENT '结束UTC时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_chat_repair_active_order` (`active_order_id`),
  KEY `idx_chat_repair_request` (`order_id`,`after_sale_id`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='PHP单写售后明确受理事实，不从processing或事件文字推断授权';
-- CHAT_END repair

-- CHAT_SECTION staff
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

-- 修复历史新装基线遗漏的平台专属表；已有升级库保持原表及资金数据。
CREATE TABLE IF NOT EXISTS `order_platform_terms` (
  `order_id` bigint(20) unsigned NOT NULL COMMENT '订单ID',
  `customer_flow_mode` varchar(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'platform_managed' COMMENT '客户参与方式：platform_managed平台托管、miniapp_booking小程序预约',
  `customer_pricing_mode` varchar(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'fixed_total' COMMENT '客户计价方式：fixed_total固定总价、itemized明细计价',
  `customer_contract_total_cents` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '客户当前最终成交金额（分）',
  `worker_settlement_mode` varchar(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'worker_collect' COMMENT '师傅工费结算：worker_collect师傅代收、platform_balance平台余额',
  `worker_labor_cents` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '当前最终师傅工费（分）',
  `extra_income_rate_bp_snapshot` int(10) unsigned NOT NULL DEFAULT '2000' COMMENT '订单外加项平台收入比例快照（万分比）',
  `booking_paid_cents` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '最终结算时平台已收预约费快照（分）',
  `customer_tail_cents` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '客户现场剩余应付（分）',
  `platform_receivable_cents` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '平台收入款待收金额（分）',
  `worker_balance_credit_cents` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '应进入师傅余额金额（分）',
  `worker_balance_freeze_days_snapshot` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '师傅余额冻结天数快照',
  `settlement_status` varchar(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'pending' COMMENT '平台承接单结算状态',
  `settled_at` datetime DEFAULT NULL COMMENT '结算完成时间',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`order_id`),
  KEY `idx_platform_terms_settlement` (`settlement_status`,`updated_at`),
  CONSTRAINT `fk_platform_terms_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='V2.5.0 平台承接单专属计价与结算条件';

CREATE TABLE IF NOT EXISTS `order_pricing_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `order_id` bigint(20) unsigned NOT NULL COMMENT '订单ID',
  `item_source` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'base' COMMENT '明细来源：base基础开单、change订单外加项',
  `change_request_id` bigint(20) unsigned DEFAULT NULL COMMENT '关联费用调整申请ID',
  `description` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '施工项目/描述',
  `note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '项目说明',
  `quantity` decimal(12,3) DEFAULT NULL COMMENT '数量/实际用量',
  `unit` varchar(24) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '计价单位',
  `unit_price_cents` bigint(20) unsigned DEFAULT NULL COMMENT '单价（分）',
  `amount_cents` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '项目金额（分）',
  `sort_order` int(11) NOT NULL DEFAULT '0' COMMENT '排序值',
  `status` varchar(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'active' COMMENT '状态',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_pricing_items_order_sort` (`order_id`,`status`,`sort_order`,`id`),
  KEY `idx_pricing_items_change` (`change_request_id`),
  CONSTRAINT `fk_pricing_items_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_pricing_items_change` FOREIGN KEY (`change_request_id`) REFERENCES `change_requests` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='V2.5.0 平台承接单结构化开单明细';

CREATE TABLE IF NOT EXISTS `platform_order_refund_reviews` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '退款财务复核单ID',
  `order_id` bigint(20) unsigned NOT NULL COMMENT '关联平台承接订单ID',
  `refund_id` bigint(20) unsigned NOT NULL COMMENT '原真实退款单ID（一退款只处理一次）',
  `refund_amount_cents` bigint(20) unsigned NOT NULL COMMENT '建档时退款成功金额快照（分）',
  `worker_labor_cents_snapshot` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '验收时师傅工费快照（分）',
  `worker_balance_credit_cents_snapshot` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '验收时实际应入师傅余额快照（分）',
  `status` varchar(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'open' COMMENT 'open待判责、awaiting_recovery待实际追偿、resolved核账结束',
  `responsibility` varchar(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'undetermined' COMMENT 'undetermined待定、platform平台、worker师傅、shared分担',
  `worker_recovery_cents` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '人工判定应由师傅补交金额（分）',
  `recovered_cents` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '已核对真实到账的线下追偿累计金额（分）',
  `decision_note` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '责任判定的事实依据',
  `recovery_reference` varchar(120) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '最近一次已核实的追偿交易流水号（完整逐笔凭证见人工收款台账）',
  `recovery_note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '线下真实追偿核验说明',
  `created_by_admin_id` bigint(20) unsigned DEFAULT NULL COMMENT '发起核账管理员ID',
  `decided_by_admin_id` bigint(20) unsigned DEFAULT NULL COMMENT '判责管理员ID',
  `resolved_by_admin_id` bigint(20) unsigned DEFAULT NULL COMMENT '核实结清管理员ID',
  `created_at` datetime NOT NULL COMMENT '建档时间',
  `decided_at` datetime DEFAULT NULL COMMENT '判责时间',
  `resolved_at` datetime DEFAULT NULL COMMENT '核账结束时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_platform_refund_review_refund` (`refund_id`),
  UNIQUE KEY `uq_platform_refund_review_recovery` (`recovery_reference`),
  KEY `idx_platform_refund_review_order_status` (`order_id`,`status`),
  KEY `idx_platform_refund_review_status_created` (`status`,`created_at`),
  CONSTRAINT `fk_platform_refund_review_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_platform_refund_review_refund` FOREIGN KEY (`refund_id`) REFERENCES `refunds` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='平台单已验收后退款资金判责与线下追偿人工核账';

CREATE TABLE IF NOT EXISTS `platform_order_manual_receipts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '实际外部收款凭证ID',
  `order_id` bigint(20) unsigned NOT NULL COMMENT '所属平台订单',
  `refund_review_id` bigint(20) unsigned DEFAULT NULL COMMENT '追偿对应退款复核单；平台收入款时为空',
  `income_order_id` bigint(20) unsigned DEFAULT NULL COMMENT '仅平台收入款填写的订单ID，唯一防重复核销',
  `receipt_kind` varchar(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'platform_income平台收入款、refund_recovery退款追偿',
  `amount_cents` bigint(20) unsigned NOT NULL COMMENT '本笔人工核验实际到账分数',
  `payment_reference` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '银行或第三方支付实际收款编号；全类型唯一',
  `verification_note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '人工核实凭据及渠道说明',
  `verified_by_admin_id` bigint(20) unsigned DEFAULT NULL COMMENT '核验管理员ID',
  `verified_at` datetime NOT NULL COMMENT '实际核验记录时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_manual_receipt_reference` (`payment_reference`),
  UNIQUE KEY `uq_manual_income_order` (`income_order_id`),
  KEY `idx_manual_receipt_review` (`refund_review_id`,`verified_at`),
  KEY `idx_manual_receipt_order` (`order_id`,`verified_at`),
  CONSTRAINT `fk_manual_receipt_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_manual_receipt_review` FOREIGN KEY (`refund_review_id`) REFERENCES `platform_order_refund_reviews` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='平台外部收款人工核验逐笔凭证，不代表微信支付或钱包入账';

CREATE TABLE IF NOT EXISTS `chat_staff_authority_versions` (
  `user_id` bigint(20) unsigned NOT NULL COMMENT '0为管理员配置，其余为真实用户；删除后保留代次',
  `authority_version` bigint(20) unsigned NOT NULL DEFAULT 1 COMMENT '只增不减，移除再加入不得复用',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='PHP权限源同事务更新，Go取共享锁校验';
INSERT IGNORE INTO `chat_staff_authority_versions` (`user_id`,`authority_version`) VALUES (0,1);
INSERT IGNORE INTO `chat_staff_authority_versions` (`user_id`,`authority_version`) SELECT id,1 FROM users;

CREATE TABLE IF NOT EXISTS `chat_policy_refresh` (
  `order_id` bigint(20) unsigned NOT NULL COMMENT '订单ID，不存消息内容',
  `checked_at` datetime NOT NULL COMMENT '上次检查UTC',
  `next_check_at` datetime NOT NULL COMMENT '下一次可检查UTC',
  `status` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'success或failed',
  PRIMARY KEY (`order_id`),
  KEY `idx_chat_policy_refresh_due` (`next_check_at`,`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='PHP授权投影恢复游标，不承担即时撤权';

-- 单语句触发器，覆盖Web/小程序/CLI/SQL维护，且回滚与原身份写入一致。
DROP TRIGGER IF EXISTS `chat_staff_settings_insert`;
CREATE TRIGGER `chat_staff_settings_insert` AFTER INSERT ON `system_settings`
FOR EACH ROW UPDATE chat_staff_authority_versions SET authority_version=authority_version+1
WHERE user_id=0 AND NEW.setting_key IN ('wechat.admin_openids','wechat.miniapp_appid');
DROP TRIGGER IF EXISTS `chat_staff_settings_update`;
CREATE TRIGGER `chat_staff_settings_update` AFTER UPDATE ON `system_settings`
FOR EACH ROW UPDATE chat_staff_authority_versions SET authority_version=authority_version+1
WHERE user_id=0 AND (OLD.setting_key IN ('wechat.admin_openids','wechat.miniapp_appid') OR NEW.setting_key IN ('wechat.admin_openids','wechat.miniapp_appid'))
AND (NOT (BINARY OLD.setting_key <=> BINARY NEW.setting_key) OR NOT (BINARY OLD.setting_value <=> BINARY NEW.setting_value) OR NOT (BINARY OLD.value_type <=> BINARY NEW.value_type));
DROP TRIGGER IF EXISTS `chat_staff_settings_delete`;
CREATE TRIGGER `chat_staff_settings_delete` AFTER DELETE ON `system_settings`
FOR EACH ROW UPDATE chat_staff_authority_versions SET authority_version=authority_version+1
WHERE user_id=0 AND OLD.setting_key IN ('wechat.admin_openids','wechat.miniapp_appid');
DROP TRIGGER IF EXISTS `chat_staff_user_insert`;
CREATE TRIGGER `chat_staff_user_insert` AFTER INSERT ON `users`
FOR EACH ROW INSERT INTO chat_staff_authority_versions(user_id,authority_version) VALUES(NEW.id,1)
ON DUPLICATE KEY UPDATE authority_version=authority_version+1;
DROP TRIGGER IF EXISTS `chat_staff_user_update`;
CREATE TRIGGER `chat_staff_user_update` AFTER UPDATE ON `users`
FOR EACH ROW UPDATE chat_staff_authority_versions SET authority_version=authority_version+1
WHERE user_id IN (OLD.id,NEW.id) AND (NOT (OLD.id <=> NEW.id) OR NOT (OLD.status <=> NEW.status));
DROP TRIGGER IF EXISTS `chat_staff_user_delete`;
CREATE TRIGGER `chat_staff_user_delete` AFTER DELETE ON `users`
FOR EACH ROW UPDATE chat_staff_authority_versions SET authority_version=authority_version+1 WHERE user_id=OLD.id;
DROP TRIGGER IF EXISTS `chat_staff_wechat_insert`;
CREATE TRIGGER `chat_staff_wechat_insert` AFTER INSERT ON `wechat_identities`
FOR EACH ROW UPDATE chat_staff_authority_versions SET authority_version=authority_version+1 WHERE user_id=NEW.user_id;
DROP TRIGGER IF EXISTS `chat_staff_wechat_update`;
CREATE TRIGGER `chat_staff_wechat_update` AFTER UPDATE ON `wechat_identities`
FOR EACH ROW UPDATE chat_staff_authority_versions SET authority_version=authority_version+1
WHERE user_id IN (OLD.user_id,NEW.user_id)
AND (NOT (OLD.user_id <=> NEW.user_id) OR NOT (OLD.app_id <=> NEW.app_id) OR NOT (OLD.openid <=> NEW.openid) OR NOT (OLD.status <=> NEW.status));
DROP TRIGGER IF EXISTS `chat_staff_wechat_delete`;
CREATE TRIGGER `chat_staff_wechat_delete` AFTER DELETE ON `wechat_identities`
FOR EACH ROW UPDATE chat_staff_authority_versions SET authority_version=authority_version+1 WHERE user_id=OLD.user_id;
-- CHAT_END staff

-- CHAT_SECTION conversation
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `chat_conversations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '独立会话ID，不等于订单ID',
  `conversation_type` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '当前仅order',
  `scope_key` varchar(96) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'PHP提供的不可变订单指派作用域',
  `order_id` bigint(20) unsigned NOT NULL COMMENT '可信订单绑定，不直接授予权限',
  `assignment_id` bigint(20) unsigned NOT NULL COMMENT '不可变指派绑定',
  `policy_version` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '已连续应用的PHP权限版本',
  `snapshot_hash` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '已应用快照指纹',
  `episode_key` varchar(96) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'PHP授权业务区间代次',
  `state` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'open或readonly；pending仅事务内',
  `created_at` datetime(6) NOT NULL COMMENT '建立时间UTC',
  `updated_at` datetime(6) NOT NULL COMMENT '投影更新时间UTC，不是消息活跃时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_chat_conversation_scope` (`conversation_type`,`scope_key`),
  UNIQUE KEY `uq_chat_conversation_binding` (`conversation_type`,`order_id`,`assignment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Go单写独立会话与可信业务绑定';

CREATE TABLE IF NOT EXISTS `chat_members` (
  `conversation_id` bigint(20) unsigned NOT NULL COMMENT '所属会话ID',
  `actor_id` bigint(20) unsigned NOT NULL COMMENT '真实用户ID，当前仅小程序身份',
  `actor_kind` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '当前仅mini，不接受后台审计成员',
  `role` varchar(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'customer/worker/platform_staff',
  `member_key` varchar(240) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '包含episode和工作人员配置/用户代次',
  `can_read` tinyint(1) NOT NULL COMMENT '最近应用快照的读取资格，仍需当前栅栏交集',
  `can_send` tinyint(1) NOT NULL COMMENT '最近应用快照的发送资格，仍需当前栅栏交集',
  PRIMARY KEY (`conversation_id`,`actor_id`),
  KEY `idx_chat_member_actor` (`actor_id`,`can_read`,`conversation_id`),
  CONSTRAINT `fk_chat_member_conversation` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Go单写当前成员投影，不复制用户账号';

CREATE TABLE IF NOT EXISTS `chat_member_intervals` (
  `conversation_id` bigint(20) unsigned NOT NULL COMMENT '所属会话ID',
  `actor_id` bigint(20) unsigned NOT NULL COMMENT '真实用户ID',
  `member_key` varchar(240) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '不可变授权身份代次',
  `start_version` bigint(20) unsigned NOT NULL COMMENT '可读消息权限版本下界，包含',
  `end_version` bigint(20) unsigned DEFAULT NULL COMMENT '可读消息权限版本上界，不包含；空表示尚未闭合',
  `open_actor_id` bigint(20) unsigned GENERATED ALWAYS AS (IF(`end_version` IS NULL,`actor_id`,NULL)) STORED COMMENT '每会话每人最多一个未闭合区间',
  PRIMARY KEY (`conversation_id`,`actor_id`,`start_version`),
  UNIQUE KEY `uq_chat_interval_open` (`conversation_id`,`open_actor_id`),
  CONSTRAINT `fk_chat_interval_conversation` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Go单写历史授权版本区间，禁止用处理时seq补权';

CREATE TABLE IF NOT EXISTS `chat_event_receipts` (
  `event_id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'PHP原始不可变事件ID',
  `aggregate_key` varchar(96) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '原始会话作用域',
  `aggregate_version` bigint(20) unsigned NOT NULL COMMENT '原始PHP权限版本',
  `payload_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '领取时原始事件指纹',
  `status` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'processing/retry/done/rejected',
  `attempts` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '领取次数，有界递增',
  `lease_owner` char(32) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL COMMENT '每次领取随机独立所有者',
  `lease_until` datetime(6) DEFAULT NULL COMMENT '服务端租约截止UTC',
  `next_attempt_at` datetime(6) NOT NULL COMMENT '失败退避后可重试时间UTC',
  `error_code` varchar(48) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL COMMENT '稳定诊断码，不存正文或SQL',
  `completed_at` datetime(6) DEFAULT NULL COMMENT '与会话投影同事务完成UTC',
  PRIMARY KEY (`event_id`),
  UNIQUE KEY `uq_chat_receipt_scope_version` (`aggregate_key`,`aggregate_version`),
  KEY `idx_chat_receipt_retry` (`status`,`next_attempt_at`),
  KEY `idx_chat_receipt_lease` (`status`,`lease_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Go单写消费回执/租约，PHP事件表只读';
-- CHAT_END conversation

-- CHAT_SECTION messages
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

SET @chat_s06_ddl = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='chat_conversations' AND COLUMN_NAME='last_seq')=0, 'ALTER TABLE `chat_conversations` ADD COLUMN `last_seq` bigint(20) unsigned NOT NULL DEFAULT ''0'' COMMENT ''同会话已提交封闭消息高水位''', 'SELECT 1');
PREPARE chat_s06_stmt FROM @chat_s06_ddl;
EXECUTE chat_s06_stmt;
DEALLOCATE PREPARE chat_s06_stmt;

SET @chat_s06_ddl = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='chat_conversations' AND COLUMN_NAME='last_change_seq')=0, 'ALTER TABLE `chat_conversations` ADD COLUMN `last_change_seq` bigint(20) unsigned NOT NULL DEFAULT ''0'' COMMENT ''同会话已提交封闭变更高水位''', 'SELECT 1');
PREPARE chat_s06_stmt FROM @chat_s06_ddl;
EXECUTE chat_s06_stmt;
DEALLOCATE PREPARE chat_s06_stmt;

SET @chat_s06_ddl = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='chat_conversations' AND COLUMN_NAME='last_message_id')=0, 'ALTER TABLE `chat_conversations` ADD COLUMN `last_message_id` bigint(20) unsigned DEFAULT NULL COMMENT ''最后正式消息ID，无待审占位''', 'SELECT 1');
PREPARE chat_s06_stmt FROM @chat_s06_ddl;
EXECUTE chat_s06_stmt;
DEALLOCATE PREPARE chat_s06_stmt;

SET @chat_s06_ddl = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='chat_conversations' AND COLUMN_NAME='last_message_at')=0, 'ALTER TABLE `chat_conversations` ADD COLUMN `last_message_at` datetime(6) DEFAULT NULL COMMENT ''最后正式消息提交UTC''', 'SELECT 1');
PREPARE chat_s06_stmt FROM @chat_s06_ddl;
EXECUTE chat_s06_stmt;
DEALLOCATE PREPARE chat_s06_stmt;

CREATE TABLE IF NOT EXISTS `chat_restrictions` (
  `actor_id` bigint(20) unsigned NOT NULL COMMENT '真实mini用户ID，永久稳定锁行，不得删除',
  `permanent` tinyint(1) NOT NULL DEFAULT '0' COMMENT '永久禁发；不限制合法查询与原业务',
  `blocked_until` datetime(6) DEFAULT NULL COMMENT '限时禁发截止UTC，空且非永久表示未限制',
  `version` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '限制变更单调代次，后续管理写入需递增',
  `updated_at` datetime(6) NOT NULL COMMENT '限制更新时间UTC',
  PRIMARY KEY (`actor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Go单写账号发送限制与稳定锁，不能按有无禁令加锁';

CREATE TABLE IF NOT EXISTS `chat_send_intents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '服务端发送意图ID',
  `sender_id` bigint(20) unsigned NOT NULL COMMENT '真实mini发送者ID',
  `conversation_id` bigint(20) unsigned NOT NULL COMMENT '授权会话ID',
  `client_message_id` varchar(43) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '10位Unix秒点32位小写hex随机数，不随重试变化',
  `fingerprint` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '版本化完整正文结构SHA256，不存被拒绝正文',
  `state` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'checking/retryable/rejected/accepted',
  `error_code` varchar(48) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL COMMENT '安全稳定诊断码，无规则证据',
  `message_id` bigint(20) unsigned DEFAULT NULL COMMENT '已提交正式消息ID，拒绝为空',
  `lease_owner` char(32) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL COMMENT '当前检查随机所有者，旧所有者不能发布',
  `lease_until` datetime(6) DEFAULT NULL COMMENT '10秒有界审核所有权截止UTC',
  `attempts` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '最多8次检查尝试，耗尽不自动换ID补发',
  `action_expires_at` datetime(6) NOT NULL COMMENT 'ID创建秒加24小时，发布前再次校验',
  `retain_until` datetime(6) NOT NULL COMMENT '至少动作截止后30天；独立于正文TTL，本阶段不清理',
  `created_at` datetime(6) NOT NULL COMMENT '首次创建UTC',
  `updated_at` datetime(6) NOT NULL COMMENT '状态更新时间UTC',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_chat_send_client` (`sender_id`,`conversation_id`,`client_message_id`),
  KEY `idx_chat_send_pending` (`sender_id`,`state`,`lease_until`),
  KEY `idx_chat_send_retention` (`retain_until`),
  CONSTRAINT `fk_chat_send_conversation` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Go单写发送意图与最小幂等结果，审核中不占消息seq';

CREATE TABLE IF NOT EXISTS `chat_messages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '独立正式消息ID，对外字符串',
  `conversation_id` bigint(20) unsigned NOT NULL COMMENT '所属会话ID',
  `seq` bigint(20) unsigned NOT NULL COMMENT '会话锁内按提交顺序分配，拒绝不占号',
  `sender_id` bigint(20) unsigned NOT NULL COMMENT '真实mini发送者ID',
  `client_message_id` varchar(43) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '原客户端动作ID',
  `policy_version` bigint(20) unsigned NOT NULL COMMENT '最终提交时PHP权限版本，不可回填改写',
  `message_type` varchar(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '本阶段仅text',
  `text_body` text COLLATE utf8mb4_unicode_ci COMMENT '原始UTF8正文，普通查询必须按安全状态过滤',
  `state` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'published/recalled/blocked，普通结果不返回正文',
  `state_version` bigint(20) unsigned NOT NULL DEFAULT '1' COMMENT '安全状态单调版本',
  `safety_rule_version` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '通过必需审核的版本',
  `created_at` datetime(6) NOT NULL COMMENT '正式发布UTC',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_chat_message_seq` (`conversation_id`,`seq`),
  UNIQUE KEY `uq_chat_message_client` (`sender_id`,`conversation_id`,`client_message_id`),
  CONSTRAINT `fk_chat_message_conversation` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Go单写已提交消息，无审核占位，历史按权限版本裁剪';

CREATE TABLE IF NOT EXISTS `chat_message_changes` (
  `conversation_id` bigint(20) unsigned NOT NULL COMMENT '所属会话ID',
  `change_seq` bigint(20) unsigned NOT NULL COMMENT '会话共享提交锁内分配的封闭变更游标',
  `message_id` bigint(20) unsigned NOT NULL COMMENT '变更所属正式消息ID',
  `state_version` bigint(20) unsigned NOT NULL COMMENT '消息安全状态版本',
  `change_type` varchar(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '当前message.accepted，后续撤回等同事务追加',
  `created_at` datetime(6) NOT NULL COMMENT '提交UTC',
  PRIMARY KEY (`conversation_id`,`change_seq`),
  CONSTRAINT `fk_chat_change_conversation` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`),
  CONSTRAINT `fk_chat_change_message` FOREIGN KEY (`message_id`) REFERENCES `chat_messages` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Go单写消息安全变更，S08再接同步分页接口';
-- CHAT_END messages

-- CHAT_SECTION moderation
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

SET @chat_s07_ddl=IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='chat_send_intents' AND COLUMN_NAME='risk_event_id')=0,'ALTER TABLE `chat_send_intents` ADD COLUMN `risk_event_id` bigint(20) unsigned DEFAULT NULL COMMENT ''风险或疑似复核事件ID，仅本人最小结果返回，不展开证据''','SELECT 1');
PREPARE chat_s07_stmt FROM @chat_s07_ddl;
EXECUTE chat_s07_stmt;
DEALLOCATE PREPARE chat_s07_stmt;

CREATE TABLE IF NOT EXISTS `chat_text_checks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '短窗口检查顺序，同作者稳定锁内登记',
  `intent_id` bigint(20) unsigned NOT NULL COMMENT '逻辑发送动作ID，重试不追加片段',
  `sender_id` bigint(20) unsigned NOT NULL COMMENT '真实mini发送者ID',
  `conversation_id` bigint(20) unsigned NOT NULL COMMENT '仅限本会话上下文，不跨群跟踪',
  `fingerprint` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '完整不可变发送内容指纹',
  `normalized_text` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '受限业务短窗口证据，不进入普通日志或普通API',
  `cache_key` char(64) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL COMMENT '环境AppID身份代次场景规则及指纹联合去重键',
  `pass_until` datetime(6) DEFAULT NULL COMMENT '仅明确官方pass缓存五分钟，不延长原判定',
  `created_at` datetime(6) NOT NULL COMMENT '首次动作登记UTC，重试不刷新窗口',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_chat_text_intent` (`intent_id`),
  KEY `idx_chat_text_context` (`sender_id`,`conversation_id`,`created_at`,`id`),
  KEY `idx_chat_text_pass` (`cache_key`,`pass_until`),
  KEY `idx_chat_text_expiry` (`created_at`),
  CONSTRAINT `fk_chat_text_intent` FOREIGN KEY (`intent_id`) REFERENCES `chat_send_intents` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Go单写两分钟最近五动作检测，十分钟后有界清理';

CREATE TABLE IF NOT EXISTS `chat_risk_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '独立风险事件ID，仅作者安全结果可引用',
  `intent_id` bigint(20) unsigned NOT NULL COMMENT '逻辑发送动作唯一，不因重试累计违规',
  `sender_id` bigint(20) unsigned NOT NULL COMMENT '真实mini发送者ID',
  `conversation_id` bigint(20) unsigned NOT NULL COMMENT '原会话ID',
  `content_fingerprint` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '原始完整内容结构指纹',
  `rule_version` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '完整检测规则版本',
  `provider` varchar(48) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '官方内容安全或本地私单检测来源',
  `reason_code` varchar(48) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '稳定规则码，不向普通接口输出命中详情',
  `provider_trace` varchar(128) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT '受限供应商追踪标识，不存整包响应',
  `risk_level` tinyint(3) unsigned NOT NULL COMMENT '1疑似待复核，2明确拦截；不直接作财务处置',
  `confirmed` tinyint(1) NOT NULL COMMENT '仅明确拦截记确认风险；审核故障不建风险',
  `disposition` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'rejected或review_pending，不自动补发',
  `review_state` varchar(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'open' COMMENT 'S19复核接续状态，当前无处理接口',
  `text_evidence` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '原文只在受控业务证据中，未来独立权限审计读取',
  `context_evidence` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '仅拆条命中的有界上下文，含动作ID指纹和规范化片段；普通接口不展开',
  `retain_until` datetime(6) NOT NULL COMMENT '至少覆盖原动作最小结果保留窗，当前不清理证据',
  `created_at` datetime(6) NOT NULL COMMENT '与发送者终态同事务提交UTC',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_chat_risk_intent` (`intent_id`),
  KEY `idx_chat_risk_actor` (`sender_id`,`confirmed`,`created_at`),
  KEY `idx_chat_risk_review` (`review_state`,`created_at`,`id`),
  CONSTRAINT `fk_chat_risk_intent` FOREIGN KEY (`intent_id`) REFERENCES `chat_send_intents` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Go单写风险证据和复核接续；普通API不返回原文，不自动罚款封号';
-- CHAT_END moderation

-- CHAT_SECTION history
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

SET @chat_s08_ddl = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='chat_conversations' AND COLUMN_NAME='sync_floor_seq')=0, 'ALTER TABLE `chat_conversations` ADD COLUMN `sync_floor_seq` bigint(20) unsigned NOT NULL DEFAULT ''0'' COMMENT ''消息补收已清理范围上界，不含可补收起点''', 'SELECT 1');
PREPARE chat_s08_stmt FROM @chat_s08_ddl;
EXECUTE chat_s08_stmt;
DEALLOCATE PREPARE chat_s08_stmt;

SET @chat_s08_ddl = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='chat_conversations' AND COLUMN_NAME='change_floor_seq')=0, 'ALTER TABLE `chat_conversations` ADD COLUMN `change_floor_seq` bigint(20) unsigned NOT NULL DEFAULT ''0'' COMMENT ''安全变更已清理范围上界，不含可补收起点''', 'SELECT 1');
PREPARE chat_s08_stmt FROM @chat_s08_ddl;
EXECUTE chat_s08_stmt;
DEALLOCATE PREPARE chat_s08_stmt;
-- CHAT_END history

-- CHAT_SECTION read
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `chat_member_reads` (
 `conversation_id` bigint(20) unsigned NOT NULL,
 `actor_id` bigint(20) unsigned NOT NULL,
 `member_key_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `read_seq` bigint(20) unsigned NOT NULL DEFAULT 0,
 `updated_at` datetime(6) NOT NULL,
 PRIMARY KEY (`conversation_id`,`actor_id`),
 CONSTRAINT `fk_chat_read_conversation` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Go单写会话已读水位，身份代次隔离';

SET @chat_unread_ddl = IF((SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='chat_messages' AND INDEX_NAME='idx_chat_unread')=0, 'ALTER TABLE `chat_messages` ADD KEY `idx_chat_unread` (`conversation_id`,`state`,`seq`,`sender_id`,`policy_version`)', 'SELECT 1');
PREPARE chat_unread_stmt FROM @chat_unread_ddl;
EXECUTE chat_unread_stmt;
DEALLOCATE PREPARE chat_unread_stmt;
-- CHAT_END read
