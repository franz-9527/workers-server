const { ChatManager } = require('./ChatManager.js')
const ApiEnvironment = require('./ApiEnvironment.js')
// S11 is delivered behind a release gate; S12/S13 provide the actual pages.
const ENABLED = false
let singleton = null
let bound = false
function get() {
 if (singleton) return singleton
 const io = {
  now: () => Date.now(), random: () => Math.random(), setTimeout, clearTimeout,
  credential: async () => (await require('./OrderApi.js').request('chat.credentials', 'POST', {})).data,
  http(path, data, token) {
   const context = ApiEnvironment.capture()
   return ApiEnvironment.ready().then(() => new Promise((resolve, reject) => {
    ApiEnvironment.assertCurrent(context)
    const origin = context.baseURL.replace(/\/api\/$/, '')
    wx.request({ url: origin + '/chat/api/v1/' + path, method: 'POST', data,
     header: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json' }, timeout: 5000,
     success(res) {
      try { ApiEnvironment.assertCurrent(context) } catch (error) { reject(error); return }
      if (res.statusCode >= 200 && res.statusCode < 300 && res.data && res.data.data !== undefined) { resolve(res.data.data); return }
      reject(Object.assign(new Error('聊天暂不可用'), { code: res.data && res.data.code || 'CHAT_UNAVAILABLE', statusCode: res.statusCode }))
     }, fail() { reject(Object.assign(new Error('聊天连接暂不可用'), { code: 'CHAT_NETWORK_ERROR', retryable: true })) }
    })
   }))
  },
  socket() { return wx.connectSocket({ url: ApiEnvironment.current().baseURL.replace(/^https:/, 'wss:').replace(/\/api\/$/, '/chat/ws') }) }
 }
 singleton = new ChatManager(io); singleton.setEnabled(ENABLED)
 if (!bound) {
  bound = true; ApiEnvironment.onChange(() => singleton.reset())
  if (typeof wx.onNetworkStatusChange === 'function') wx.onNetworkStatusChange(event => singleton.setNetwork(event.isConnected))
 }
 return singleton
}
module.exports = { get, onShow: () => get().setForeground(true), onHide: () => get().setForeground(false), reset: () => { if (singleton) singleton.reset() } }
