const test = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const vm = require('node:vm')
const { ChatManager } = require('../miniprogram/utils/ChatManager.js')
const flush = async () => { for (let i = 0; i < 12; i++) await new Promise(resolve => setImmediate(resolve)) }
function fixture(handler) {
 let serial = 0; let time = 1000000
 const timers = new Map(); const sockets = []; const calls = []; const events = []
 const io = {
  now: () => time, random: () => 0.5,
  setTimeout(fn, delay) { const id = ++serial; timers.set(id, { fn, delay }); return id }, clearTimeout(id) { timers.delete(id) },
  async credential() { calls.push(['credential']); return { access_token: 'memory-only', expires_at: new Date(time + 300000).toISOString() } },
  async http(path, data, token) { calls.push([path, data, token]); if (handler) return handler(path, data, token); if (path === 'auth/socket-ticket') return { ticket: 'one-use' }; return { items: [], has_more: false } },
  socket() {
   const task = { sent: [], closed: false, onOpen(fn) { this.open = fn }, onMessage(fn) { this.message = fn }, onClose(fn) { this.closeEvent = fn }, onError(fn) { this.error = fn }, send(data) { this.sent.push(JSON.parse(data.data)) }, close() { this.closed = true }, receive(type, payload, id = 'server') { this.message({ data: JSON.stringify({ protocol_version: 1, request_id: id, type, payload }) }) }
   }
   sockets.push(task); return task
  }
 }
 const m = new ChatManager(io); m.subscribe((type, data) => events.push([type, data]))
 return { m, io, timers, sockets, calls, events, advance: n => { time += n } }
}
async function connected(f) { f.m.setEnabled(true); f.m.setForeground(true); await flush(); const s = f.sockets.at(-1); s.open(); s.receive('auth.ok', { actor_id: '1', expires_at: (f.io.now() + 300000) / 1000 }); return s }
const message = (seq, state = 'published', version = '1') => ({ message_id: seq, seq, sender_id: '2', policy_version: '1', state_version: version, state, text: 'text-' + seq })
function history(path, data) {
 if (path === 'auth/socket-ticket') return { ticket: 'ticket' }
 if (path === 'conversations/digests') return { items: [{ conversation_id: 'other-order', unread: { unread_count: 1 } }], has_more: false }
 if (path === 'conversations/bootstrap') return { messages: [message('100')], changes: [], policy_version: '1', sync_cursor: 'signed-100', change_cursor: 'change-100' }
 if (path === 'messages/sync') { const previous = Number(data.cursor.split('-')[1]); const seq = Math.min(103, previous + 1); return { messages: seq > previous ? [message(String(seq))] : [], policy_version: '1', sync_cursor: 'signed-' + seq, has_more: seq < 103 } }
 if (path === 'messages/changes') return { messages: [], changes: [{ message: message('100', 'recalled', '2') }], policy_version: '1', change_cursor: 'change-101', has_more: false }
 throw Error(path)
}
test('default gate has no network calls; multiple starts keep one socket; hide cancels timers', async () => {
 const f = fixture(); f.m.setForeground(true); await flush(); assert.equal(f.calls.length, 0)
 f.m.setEnabled(true); f.m.start(); f.m.start(); await flush(); assert.equal(f.sockets.length, 1); assert.equal(f.calls.filter(c => c[0] === 'credential').length, 1)
 f.m.setForeground(false); assert.equal(f.timers.size, 0); assert.equal(f.sockets[0].closed, true)
})
test('103 hint does not skip 101/102; both streams restore recall; account recovery runs on every page', async () => {
 const f = fixture(history); const socket = await connected(f); f.m.focus('order-A')
 socket.receive('message.new', { conversation_id: 'order-A', highest_seq: '103' })
 assert.equal(f.m.cache.size, 0)
 await f.m.reconcile()
 const model = f.m.cache.get('order-A'); assert.deepEqual([...model.messages.keys()], ['100', '101', '102', '103'])
 assert.equal(model.sync, 'signed-103'); assert.equal(model.changes, 'change-101'); assert.equal(model.messages.get('100').text, undefined)
 assert.equal(f.calls.some(c => c[0] === 'conversations/read'), false)
 assert.equal(f.events.some(e => e[0] === 'digests' && e[1].items[0].conversation_id === 'other-order'), true)
 f.m.focus(''); await f.m.reconcile(); assert.equal(f.calls.filter(c => c[0] === 'conversations/digests').length, 2)
 f.m.setForeground(false)
})
test('older message state cannot restore recalled text in cache or emitted pages', () => {
 const f = fixture(); const model = { messages: new Map() }
 f.m.merge(model, { messages: [message('4', 'recalled', '3')] })
 const page = f.m.merge(model, { messages: [message('4', 'published', '1')] })
 assert.equal(model.messages.get('4').state_version, '3'); assert.equal(page.messages[0].state, 'recalled'); assert.equal(page.messages[0].text, undefined)
})
test('socket timeout queries original send id using HTTP; transport failure never mints another id', async () => {
 const f = fixture((path, payload) => { if (path === 'auth/socket-ticket') return { ticket: 'ticket' }; if (path === 'messages/result') return { state: 'accepted', client_message_id: payload.client_message_id }; return { items: [], has_more: false } })
 await connected(f); const request = { conversation_id: '1', client_message_id: 'original-id', text: 'text' }
 const pending = f.m.command('message.send', request); const timer = [...f.timers.entries()].find(([, t]) => t.delay === 5000); assert.ok(timer); f.timers.delete(timer[0]); timer[1].fn()
 const result = await pending; assert.equal(result.client_message_id, 'original-id'); assert.equal(f.calls.find(c => c[0] === 'messages/result')[1].client_message_id, 'original-id'); assert.equal(f.calls.some(c => c[0] === 'messages/send'), false)
 f.m.setForeground(false)
})
test('WSS outage uses bounded HTTP cadence; entire Go outage reports unavailable and backs off', async () => {
 let unavailable = false
 const f = fixture((path) => { if (unavailable) throw Object.assign(Error('down'), { code: 'CHAT_NETWORK_ERROR' }); return path === 'auth/socket-ticket' ? { ticket: 'ticket' } : { items: [], has_more: false } })
 const s = await connected(f); s.error({}); await f.m.reconcile(); assert.equal(f.m.state, 'http'); assert.ok([...f.timers.values()].some(t => t.delay === 7500)); assert.ok([...f.timers.values()].some(t => t.delay === 1000))
 unavailable = true; await assert.rejects(f.m.reconcile()); assert.equal(f.m.state, 'unavailable'); assert.ok([...f.timers.values()].some(t => t.delay === 5000)); f.m.setForeground(false)
})
test('identity reset discards a late response and clears cursors/body without persisting anything', async () => {
 let release
 const f = fixture((path) => path === 'conversations/digests' ? new Promise(resolve => { release = resolve }) : { ticket: 'ticket' })
 await connected(f); const job = f.m.reconcile(); await flush(); assert.ok(release)
 f.m.digestCursor = 'old-account'; f.m.cache.set('private', { text: 'old' }); f.m.reset(); f.m.setForeground(false)
 release({ items: [{ conversation_id: 'secret' }], has_more: false }); await assert.rejects(job)
 assert.equal(f.m.cache.size, 0); assert.equal(f.m.digestCursor, ''); assert.equal(f.events.some(e => e[0] === 'digests'), false); assert.equal(f.timers.size, 0)
})
test('focus switch rejects a previous conversation response', async () => {
 let release
 const f = fixture((path, data) => path === 'conversations/bootstrap' ? new Promise(resolve => { release = resolve }) : history(path, data))
 await connected(f); f.m.focus('old'); const job = f.m.reconcile(); await flush(); f.m.focus('new'); release(history('conversations/bootstrap')); await job
 assert.equal(f.m.cache.has('old'), false); f.m.setForeground(false)
})
test('resync clears the old window and a new bootstrap recreates it', async () => {
 let stale = true
 const f = fixture((path, data) => { if (path === 'messages/sync' && stale) throw Object.assign(Error('expired'), { code: 'CHAT_RESYNC_REQUIRED' }); return history(path, data) })
 await connected(f); f.m.focus('A'); await assert.rejects(f.m.reconcile()); assert.equal(f.m.cache.size, 0); assert.equal(f.events.some(e => e[0] === 'conversation.clear'), true)
 stale = false; await f.m.reconcile(); assert.equal(f.m.cache.has('A'), true); f.m.setForeground(false)
})
test('account pagination continues bounded batches and background performs no reconciliation', async () => {
 let pages = 0
 const f = fixture((path) => { if (path === 'auth/socket-ticket') return { ticket: 'ticket' }; pages++; return { items: [], has_more: pages < 5, next_cursor: pages < 5 ? 'page-' + pages : '' } })
 await connected(f); await f.m.reconcile(); assert.equal(pages, 3); assert.equal(f.m.digestCursor, 'page-3'); await f.m.reconcile(); assert.equal(pages, 5); assert.equal(f.m.digestCursor, '')
 f.m.setForeground(false); await f.m.reconcile(); assert.equal(pages, 5)
})
test('network restoration creates a new socket, and typing uses only the current socket with local throttle', async () => {
 const f = fixture(); await connected(f); f.m.focus('A'); const first = f.m.typing(true); assert.equal(await f.m.typing(true), false)
 const task = f.sockets[0]; const sent = task.sent.at(-1); task.receive('typing.result', { active: true }, sent.request_id); await first
 f.m.setNetwork(false); assert.equal(f.timers.size, 0); f.m.setNetwork(true); await flush(); assert.equal(f.sockets.length, 2); f.m.setForeground(false)
})
test('OrderApi cannot save a late login token after identity invalidation', async () => {
 const storage = new Map(); const requests = []; const logins = []; let resets = 0
 const context = { key: 'production', revision: 0, baseURL: 'https://example.invalid/api/' }
 const apiEnv = { onChange() {}, capture: () => context, ready: async () => {}, assertCurrent() {}, storageKey: k => k }
 const sandbox = { module: { exports: {} }, Set, Promise, console, setTimeout, require(path) { if (path.includes('ApiEnvironment')) return apiEnv; if (path.includes('config')) return { APICONFIG: { VERSION: '2.7.0' } }; if (path.includes('ChatRuntime')) return { reset() { resets++ } }; throw Error(path) }, wx: { getStorageSync: k => storage.get(k), setStorageSync: (k, v) => storage.set(k, v), removeStorageSync: k => storage.delete(k), login: opts => logins.push(opts), request: opts => { requests.push(opts); return {} } } }
 vm.runInNewContext(fs.readFileSync(require.resolve('../miniprogram/utils/OrderApi.js'), 'utf8'), sandbox)
 const api = sandbox.module.exports; const job = api.login(false); await flush(); api.invalidateSession(); logins[0].success({ code: 'test-code' }); await flush(); requests[0].success({ statusCode: 200, data: { ok: true, data: { token: 'old-token' } } }); await assert.rejects(job, e => e.code === 'CHAT_CONTEXT_CHANGED'); assert.equal(storage.size, 0); assert.equal(resets, 1)
})
